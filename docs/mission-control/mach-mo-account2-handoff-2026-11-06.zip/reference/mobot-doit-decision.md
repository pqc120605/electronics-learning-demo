# Decision — MOBOT-DEVKIT-DOIT

- Related tasks: MM-HW-MOBOT-IF-001, MM-HW-MOBOT-REMOTE-KICAD-001, MM-HW-MOBOT-ROBOT-KICAD-001.
- Decision owner: User.
- State: decided for target selection; exact revision and implementation evidence pending.
- Source: User explicitly selected the [DOIT ESP32-DEVKIT-V1 listing](https://www.snapeda.com/parts/ESP32-DEVKIT-V1/Do%20it/view-part/) in HQ.

## Outcome

Use the DOIT ESP32-DEVKIT-V1 named in the link as the target for the next MoBot carrier configuration, replacing BrijModi as the planned hardware reference. Handset first, robot second. The listing provides a CAD reference and warns that SnapMagic did not create the symbol or footprint. Validate both against the exact module revision before use.

Box09 identifies the module revision and source chain, pinout, mechanical drawing and board-level schematic, and records legal public CAD downloads with hashes if available. Box03 reconciles header geometry/orientation, USB connector location and enclosure fit, then lists changes required in the carrier and BOM. Box02 verifies the USB bridge and VDD/REGIN/VBUS wiring, current and power-path assumptions, and the interposer/fault gates on the selected revision. Box08 independently reviews the integrated packet.

Board selection does not establish that DOIT shares the BrijModi power path or pinout. The original BrijModi reference remains historical evidence. R7 bytes and approval records remain intact. Incorporate the verified board and outstanding carrier changes into a new configuration revision/hash before asking for approval and running preflight. No KiCad lease, physical testing or procurement follows from this decision alone.

## Exit evidence

- Exact manufacturer/SKU/revision, module and USB bridge marking, with a source-to-board match.
- Header row/spacing, pin 1, pin order, mounting, USB clearance, antenna keepout and footprint comparison.
- Verified USB power/data path and whether earlier CP2102 findings apply to this exact board. Track the carrier-side break-before-make, backfeed, latch, USB current and pack/charger issues separately.
- Bench checks and exact board measurements remain pending until separately authorized.
