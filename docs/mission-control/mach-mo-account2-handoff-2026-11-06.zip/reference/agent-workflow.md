# Mạch Mở — quy trình làm việc cho Agents

**Latest user override — bounded parallel builders (05/11/2026):** for Mạch Mở, read [parallel-build-policy](../../electronics-learning-demo/docs/mission-control/parallel-build-policy.md). Software/hardware workers may implement only their own active lead-issued nonoverlapping lease; lead alone updates queue/config/decisions. Hardware pin/schematic/PCB/CAD/firmware/build waits for explicit user-approved configuration/hash and resolved blockers. Old read-only/one-writer wording below is the advisory/no-lease fallback, not a ban on the newly authorized builder model. Existing foundations may be replaced through scoped redesign/migration; the legacy implementation is not fixed.

**FINAL v1:** [Bản chốt](../mach-mo-final-2026-11-05.md). Schema v2 ở mục cuối ưu tiên khi ví dụ cũ chưa đủ trường.

**Hiệu lực:** 05/11/2026. **Mô hình:** Codex lead điều phối, chọn specialist theo việc, một người ghi file, review độc lập và kiểm chứng theo snapshot. Không trao đổi với Claude.

## 1. Bắt đầu trong một phút

Đưa một yêu cầu theo một trong các cách sau; lead tự routing và chuẩn bị task phù hợp:

```text
Chạy quy trình Mạch Mở cho yêu cầu: [kết quả tôi muốn].
```

```text
Bắt đầu task MM-BASE-001 theo docs/agents/tasks.json.
```

```text
Thiết kế feature OBS-04 tới D3, dựa trên hiện trạng; chưa triển khai code.
```

```text
Review task [ID] trên snapshot hiện tại, tập trung các tiêu chí nghiệm thu.
```

```text
Cho tôi trạng thái: đang làm gì, đã kiểm chứng gì, đang chờ gì, bước tiếp theo.
```

Đây là quy trình vận hành, không phải lịch tự chạy. Tạo queue không tự khởi động feature, deploy, mua hàng hoặc nạp thiết bị. Nếu user đã giao thực thi task trong phạm vi đủ rõ thì tiếp tục các bước cần thiết, không hỏi lại quyền làm chính task đó.

## 2. Bộ hồ sơ dùng chung — nguồn nào quyết định điều gì

| Hồ sơ | Mục đích / người ghi |
|---|---|
| [Product master](../mach-mo-product-master-2026-11-05.md) | Đích sản phẩm, 14 module/143 capability; PSA đề xuất, lead ghi |
| [Feature/depth register](../product/2026-11-05-mach-mo-feature-depth-register.md) | Capability IDs, chiều sâu và dependencies; không tự đánh dấu đạt bằng một task |
| [Architecture/roles/crosswalk](../product/2026-11-05-mach-mo-product-architecture-and-roles.md) | K-* contracts, 8 roles, W1–W7, G1–G6 và 38 task nền |
| [tasks.json](tasks.json) | **Nguồn duy nhất của trạng thái task hiện hành**; chỉ lead cập nhật |
| `docs/agents/runs/<task-id>/` | Scope/task card, handoffs, review, test và decisions của từng lượt; lead tạo khi bắt đầu, không tạo folder rỗng hàng loạt |
| [Role cards](roles.md) | Input/output/trách nhiệm từng vai trò; chỉ đọc card liên quan |
| [Templates](templates/task.md) | Mẫu task/handoff/review/test/decision để không thiếu dữ kiện |
| Project source + fresh check output | Bằng chứng implemented behavior; kế hoạch/status cũ không thay source |

Các plan/checklist khác vẫn được giữ làm thiết kế/lịch sử. Khi task đổi trạng thái chỉ cập nhật `tasks.json`; milestone trong plan được phản chiếu khi có một slice hoàn chỉnh. Không duy trì hai bảng trạng thái cạnh tranh. Planning-with-files dùng để theo dõi hoạt động của phiên lead; không thay queue sản phẩm.

`runs/` chứa evidence, không secrets hoặc source import chưa lọc. Attempt đầu dùng folder task; khi reopen, tạo `attempt-N/`, cập nhật refs hiện hành trong queue và giữ nguyên reports cũ. Test output chuẩn nằm ở nơi tool tạo, ví dụ product `.tmp/`; report chỉ link artifact và giữ revision/hash. Specialist trả nội dung cho lead để ghi, không tự rewrite board hoặc file người khác.

## 3. Tổ chức nhân sự logic và quyền ghi

8 role cards đã khớp các role cấu hình sẵn; lượt này không cài agent/model/server mới. Tên runtime xem [roles.md](roles.md).

- **Lead:** nhận yêu cầu, chọn slice, phân công, sở hữu mọi thay đổi file, tích hợp và quyết định trạng thái. Lead có thể trực tiếp thực hiện vai trò SE hoặc PSA, không cần spawn agent để tự nhắc lại kế hoạch.
- **Specialist:** chỉ đọc phạm vi được giao, thiết kế/phản biện và trả handoff có chứng cứ. Không sửa source, docs, queue hoặc nhờ agent khác review tiếp.
- **QA:** review độc lập với người tạo implementation; kết luận pass/changes_requested/insufficient_evidence trên snapshot cụ thể.
- **TST:** thực thi phép kiểm được giao. Được tạo log/trace/build artifacts bởi lệnh test; không sửa implementation hoặc tự đổi assertion để làm test xanh.

Default chỉ một filesystem writer tránh xung đột trong checkout dùng chung. Nếu sau này user chủ động chọn worker implementation, phải có task sửa mô hình quyền/ownership và isolation rõ; không tự suy quyền đó từ role description “implements”.

## 4. Routing — gọi đúng người, đúng lúc

| Loại yêu cầu | Lead làm gì | Specialist cần chọn | Review / kiểm chứng |
|---|---|---|---|
| Hỏi nhanh, typo/copy nhỏ không đổi claim | Đọc chỗ liên quan, trả lời/sửa hẹp | Không bắt buộc | Self-check đúng phạm vi; không thêm suite vô ích |
| Tính năng/flow UI | Đóng slice/capability; làm implementation | UX; LXD nếu đổi hoạt động học | QA/TST cho interaction/state/data có ảnh hưởng; browser theo thay đổi |
| Bài học/assessment | Chốt outcome/activity/context trước code | LXD; EF kiểm claims điện/code | Rubric/answer cases, ungradable, self-report semantics và learner flow |
| Board/part/pin/model/instruments | Đối chiếu exact revision và provider | EF; HK nếu variant/BOM/physical; UX nếu presentation | Fixture numeric/target/units; QA claims và source; không tự suy hardware |
| Storage/import/export/refactor | Xác định invariants/recovery/compatibility | SE do lead; UX cho error/repair states | QA độc lập; TST legacy/future/quota/roundtrip/stale state |
| EDA/firmware/IoT/robot | Chốt K-* port, target và method trước feature | EF; HK cho hardware; PSA nếu thêm service/bridge/phạm vi | Spike nếu R; explicit expected/actual; physical gate chỉ khi đủ mẫu |
| Kit/PCB/sourcing/assembly | Tách concept/design/physical validation | HK + EF; LXD cho lesson/teacher handoff | BOM/revision/measurements/inspection; chờ samples không ngăn design độc lập |
| Kiến trúc/cross-module | Chốt interface/ownership/alternatives/slice | PSA + tối đa 1–2 specialist đúng ranh giới | QA review plan/contracts; sau code kiểm các invariants và regression |
| Public release/device/external action | Chuẩn bị artifact/evidence cụ thể trước | QA và EF/HK theo scope | Gate kỹ thuật + quyền hành động thực sự; không coi sẵn task là được deploy/flash |

Một thay đổi nhỏ không bắt buộc đủ mọi role. Một người reviewer có thể trả cả nhận xét QA và test design; nếu chưa thực thi phép kiểm thì không được gọi đó là test passed. Với thay đổi code không tầm thường, reviewer phải khác người implement; nếu chưa có reviewer thì trạng thái `in_review`, không tự ký done.

### Routing theo module

- M01: UX; M02: LXD (+EF nếu điện/code); M03: EF (+HK nếu variant/asset/kit).
- M04/M11: lead SE; thêm UX khi interaction/error states, QA cho data contracts.
- M05/M06/M07/M08/M09: EF; M08 thêm UX; M09 thêm PSA khi service/network decision.
- M10: EF+HK, LXD cho mission; M12: HK+EF; M13: LXD+PSA.
- M14: PSA, QA cho gates/policy, LXD cho content/tutor; implement source vẫn do lead SE.

## 5. Vòng đời task

```mermaid
flowchart LR
  B[backlog] --> S[scoped]
  S --> R[ready]
  R --> I[in_progress]
  I --> V[in_review]
  V --> T[in_test]
  T --> D[done]
  V -->|changes requested| I
  T -->|verified defect| I
  I -. blocked input .-> W[waiting]
  S -. missing decision .-> W
  W -. blocker cleared .-> S
```

`waiting` có `resume_state`; sơ đồ chỉ minh họa, bảng dưới là luật đầy đủ. **Lead là người chuyển trạng thái** dựa trên handoff/evidence, không phải agent tự tuyên bố xong.

| Trạng thái | Được vào khi / được ra khi |
|---|---|
| `backlog` | Có mục tiêu/capability/owner sơ bộ; chưa hứa bắt đầu. Có thể sang scoped hoặc cancelled theo scope được giao. |
| `scoped` | Có problem/entry→exit depth, allowed files, dependencies, acceptance/test strategy. Sang ready khi DoR đạt; hoặc waiting/cancelled. |
| `ready` | Đủ chuẩn bị để giao việc: DoR đủ, dependencies done hoặc hợp đồng upstream cần dùng đã nghiệm thu và được ghi tường minh. Chưa tự có quyền thực thi. Chỉ sang in_progress khi current request/task cha đã giao đúng scope và lead đặt `execution_requested=true`; có thể trả scoped nếu scope đổi hoặc waiting nếu phát sinh blocker. |
| `in_progress` | Có authorization cho scope hiện tại và `execution_requested=true`; chỉ một active writer; dùng scope/contract đã chốt. Sang in_review khi deliverable và self-check sẵn; waiting nếu thiếu input thật; cancelled khi user/owner quyết định bỏ scope. |
| `in_review` | Reviewer nhận snapshot+acceptance, không dựa lời implementer. Pass→in_test; changes_requested→in_progress; thiếu evidence→waiting hoặc bổ sung ngay trong phạm vi được phép; user/owner hủy scope→cancelled. |
| `in_test` | Chạy checks cần cho snapshot đã review. Pass + DoD→done; defect→in_progress; thay đổi materially sau review→in_review; thiếu môi trường/thiết bị→waiting; user/owner hủy scope→cancelled. |
| `waiting` | Ghi blocker cụ thể, người gỡ, việc độc lập vẫn làm được và resume_state. Khi điều kiện có thật mới resume; thời gian trôi không là approval. User/owner có thể hủy thành cancelled. |
| `done` | Deliverable+review+verification đúng scope và snapshot, residual limits rõ. Nếu reopen: quay scoped, tăng attempt và giữ evidence cũ. |
| `cancelled` | User/owner quyết định không tiếp tục; ghi lý do, không giả done. |

Không nhảy ready→done cho code non-trivial. Với câu hỏi/typo không cần queue formal, dùng đường nhỏ ở §4; nếu vẫn ghi task, review/test có thể là self-check **được nêu N/A có lý do**, không tạo bằng chứng độc lập giả.

## 6. Definition of Ready — trước khi thực hiện

- Có task definition truy được về user request hoặc backlog sản phẩm, scope và mục đích rõ. `ready` là đủ chuẩn bị để giao việc, không là quyền bắt đầu. Quyền thực thi được kiểm tại `ready→in_progress` theo current request/task cha; lead ghi `execution_requested=true` trước thực hiện. Không hỏi lại nếu quyền cho scope đó đã có.
- Một owner A; một writer chính; reviewer/tester biết ai và có thể được điều phối đúng stage.
- Capability IDs tồn tại, module/legacy task links, entry/exit depth và deliverable cụ thể. Process-only task có thể không nâng depth, phải ghi rõ.
- Input facts khác assumptions; nguồn/date/version và actual state cần đọc được nêu rõ.
- Allowed paths / forbidden paths; expected API/schema hoặc phần design task phải tạo; dependencies rõ.
- Acceptance có test cases/exact outputs hoặc review checklist phù hợp; rollback/recovery nếu thay dữ liệu/contract.
- Quyết định cần cho task đã có; phần chưa rõ không ảnh hưởng thì ghi assumption và tiếp tục, không dừng cả luồng. Phần thật sự phụ thuộc thì waiting riêng task đó.

Giao scope quá lớn → lead tách vertical slice có thể test. Không giao một agent “xây toàn bộ M07” hoặc paste cả 143 feature vào context.

## 7. Bảy bước vận hành

### 1 — Intake và triage

Lead đọc request, root/project AGENTS và task hiện hành. Chốt loại công việc, capability IDs, phạm vi và điều đã được user cho phép. Không tự biến “thiết kế workflow” thành sửa sản phẩm. Tra source/tài liệu có sẵn trước khi hỏi dữ kiện đã tồn tại.

### 2 — Context packet và scope

Dùng [task template](templates/task.md). Đưa cho specialist đúng file/snippet, mục tiêu, constraints và expected output. Không fork toàn bộ lịch sử nếu một packet ngắn đủ dùng. Nêu rõ họ không làm một mình, không revert người khác và mặc định read-only.

Với code: kiểm trạng thái checkout hiện tại và source snapshot trước edit; không dùng kết quả 04/11 như kết quả mới. Product có thể untracked trong Git cha; nếu diff không bao trùm thì lưu selected file list+hashes trước/sau. Không tự stage/commit toàn bộ workspace.

### 3 — Domain design / contract handoff

Chọn roles theo §4. Domain owner trả [handoff](templates/handoff.md): findings đã kiểm/assumptions, contract/input/output/errors, acceptance và thay đổi tối thiểu. Lead đối chiếu code, xử lý bất đồng bằng evidence; không nhập tất cả đề xuất như mệnh lệnh.

Routine choices do lead chốt trong scope. Product choices vượt scope như required account/service/target/kit SKU/release action cần decision record, và chỉ hỏi user nếu thiếu quyết định thực sự. Nếu user đã quyết định trước đó thì ghi lại, không hỏi lại.

### 4 — Implementation / artifact production

Lead thực hiện với vai trò SE hoặc ghi design/content/hardware proposal đã được review. Một slice nhỏ; giữ facade/migration/recovery. Không thêm package, gọi compile cloud, network/device action hay source ngoài scope chỉ để vượt test. Khi phát sinh file cần sửa ngoài allowed paths: ghi lý do, cập nhật scope và ownership trước; không lặng lẽ sửa.

Thay đổi spec/API có caller khác → cập nhật contract và những task bị ảnh hưởng. Một task không tự nâng capability D3 chỉ vì component render. Spec và tests phải mô tả phương pháp/limits đúng.

### 5 — Review độc lập

Giao [review packet](templates/review.md) với snapshot, changed-file list/diff, acceptance, actual checks và open questions. Reviewer trả verified findings (severity/file/line/repro/impact), unverified concerns riêng. Lead xác minh trước sửa.

Phân biệt product correctness, data preservation, educational/electrical claim và release gate. Không yêu cầu reviewer chạy toàn suite nếu TST được giao stage riêng. Sau hai vòng không hội tụ, tách câu hỏi/fixture/contract nhỏ hơn và dùng domain owner; không lặp agent calls vô hạn hoặc xin thêm “ý kiến thứ ba” không có câu hỏi mới.

### 6 — Verification theo scope

Dùng [test report](templates/test-report.md). Chỉ một test runner cho port/build/output dùng chung; không sửa source trong lúc suite đang kiểm snapshot. TST kiểm command, exit code, expected/actual và artifact, không chỉ đọc dòng “passed”.

- Docs/process: link/schema/queue/role/transition checks và scenario dry run; không rerun product build chỉ vì thay tài liệu.
- Data/parser/runtime: targeted regression + typecheck; broaden full suite/build khi ảnh hưởng justified.
- UI/journeys: browser automation và manual interactions tương ứng; axe không thay keyboard/screen reader.
- Simulation: golden numeric/firmware/time/source/target fixtures; missing capability là unsupported/ungradable.
- Hardware: exact sample/revision/firmware/instrument/conditions; không có sample thì chưa physical pass.
- Public: chạy artifact gate trên đúng file/profile/hash; `build:local` xanh không thay public verdict.

Known baseline failures phải được ghi với scope/date, không tự miễn regression mới. Muốn ghi done cho task chỉ điều tra một failure thì deliverable là reproduction/report; không được báo sản phẩm đã sửa hoặc suite xanh.

### 7 — Close và next task

Lead kiểm DoD, cập nhật queue/handoff/status docs cần thiết và report ngắn: thay gì, evidence, giới hạn, bước tiếp theo. Done của task không là authorization deploy/merge/flash. Nếu user giao cả chuỗi tasks thì tiếp tục task ready kế tiếp trong scope; nếu chỉ giao một việc thì không tự chạy hết backlog.

## 8. Definition of Done và evidence freshness

- Acceptance của task được đáp ứng, code/content/artifact ở path đã giao, reviewer verdict phù hợp.
- Evidence gắn đúng scope/snapshot. Recorded source revision là Git commit/diff nếu đầy đủ; khi untracked dùng file hashes/manifest. Không reuse test pass của snapshot cũ sau sửa logic liên quan.
- Test/review results có method/command/date/environment/expected/actual; unsupported/unrun/unknown được giữ rõ.
- Không còn verified P0/P1 trong phạm vi task/release claim. P2 còn lại có owner/mitigation/task; hard gates về data preservation/target truth/public artifact/physical validation không được waive thành pass.
- Docs/feature state chỉ cập nhật mức đã chứng minh; self-report/runStarted/evidence/physical không trộn.
- Queue có links đến handoff/review/test, residual risks và next action. Fresh source checks không bắt buộc rerun khi chỉ sửa prose không ảnh hưởng behavior; nêu vì sao previous evidence còn applicable.

`done` của task research/docs có thể hợp lệ khi product public vẫn blocked hoặc hardware chưa đo, miễn đó không phải deliverable task. Ghi gate verdict riêng `pass / fail / unknown / not_applicable` theo scope, không ép mọi task phải release được toàn sản phẩm.

## 9. Parallelism, WIP và shared state

- Session hiện có tối đa 4 concurrent agents tính cả lead. Đợt design thường lead + 1–2 domain specialists; review/test stage sau, không bắt tất cả roles cùng chạy.
- Default WIP: **1 task đang ghi file**, tối đa **2 advisory investigations độc lập**. Tasks chung schema/contract phải chốt interface trước; hai role không tự sửa hai bản schema.
- Chỉ lead sửa queue/decisions/shared planning. Tester giữ exclusive port/build-output trong lúc chạy; parallelize đọc nguồn độc lập, không parallel build/dev servers trên cùng port.
- Reviewer/tester nhận đúng revision. Trong lúc review một snapshot, lead có thể làm việc độc lập khác không chạm phạm vi; nếu sửa phạm vi được review thì đánh dấu snapshot cũ và re-review phần ảnh hưởng.
- Không tạo chat/sidebar task mới cho subtasks; dùng specialist hiện có hoặc subagent khi được phép. Không nhờ specialist gọi agent tiếp.
- Handoffs ngắn, link file/line/evidence; không truyền secrets, file riêng tư ngoài scope hoặc raw logs khổng lồ.

## 10. Packet giao agent dùng ngay

```text
Task: [ID] — [mục tiêu và exit depth].
Role: [runtime role name]; mode: read-only advisory / execute-checks.
Working directory: D:/StartupOS/electronics-learning-demo.
Read: [AGENTS + đúng role card + 3–6 input files/snippets].
Own: [câu hỏi/trách nhiệm cụ thể]; filesystem writer là Codex lead.
Allowed scope: [paths/contracts]; forbidden: sibling app, secrets, unrelated files.
Constraints: no Claude, no subagents, no source/docs/queue edits.
For tester: only assigned commands/artifact paths; no implementation/test assertion edits.
You are not alone; preserve others' work and report scope conflicts.
Return: verified facts vs assumptions, proposed contract/delta, acceptance/evidence,
open blockers and one next action using handoff/review/test template as appropriate.
Do not claim execution, physical validation or independent review you did not perform.
```

## 11. Starter queue và cách tiếp tục

[tasks.json](tasks.json) chứa task process setup và queue seed cho baseline/contract/BOM/data. Queue **không nhập cả 143 feature thành 143 tickets**. Giữ register là destination; chỉ tạo executable task khi slice/inputs/acceptance đủ rõ.

Task sẵn đầu tiên là **MM-BASE-001**: snapshot + xác minh baseline mới, read-only đối với source. Các con số cũ là input lịch sử. Sau output đó, lead chọn task contract/fix tương ứng; không bắt đầu bằng refactor lớn hoặc phần cứng chưa có evidence.

Các mẫu còn lại: [handoff](templates/handoff.md), [review](templates/review.md), [test](templates/test-report.md), [decision](templates/decision.md). Xem [biên bản kiểm chứng workflow](validation-2026-11-05.md) để biết điều gì đã thực sự được kiểm trong lúc thiết lập.

## 12. Quy tắc chốt — schema v2
- Queue là nguồn duy nhất về state/dependency. Ready không cấp phép chạy; active task cần execution_requested=true và thuộc yêu cầu hiện tại.
- History append-only; imported_snapshot ghi nhận trạng thái cũ, không dựng lịch sử chưa biết. Reopen tăng attempt, cancel giữ record.
- waiting cần reason, owner, resume_condition, resume_state. Chỉ resume khi điều kiện đạt, ghi history.
- gates tách software/public/hardware. required_gates theo scope; done cần review/verification và required gates pass; không biến unknown thành pass.
- snapshot phân biệt pending/historical/file-hashes. Trước/sau advisor, lead lưu manifest SHA-256 các source trong packet, queue, role profile và chỉ dẫn; so sánh mutation. Snapshot lịch sử không chứng minh source hiện tại pass.
- Tám role profile ghi read-only/no-dispatch: đây là instruction, không phải OS sandbox. Lead ghi duy nhất, advisor không gọi advisor khác/Claude. Tester chỉ chạy check/artifact đã scope, không sửa source/tests. Web research cần packet cho phép, không tự upload.
- Agent đang tồn tại có thể giữ instruction cũ: packet tiếp theo phải chứa policy mới; sửa TOML không cập nhật tức thời agent đang chạy.
- QA độc lập không khả dụng thì implementation quan trọng giữ in_review; không tự ghi QA pass. Final thiết kế được giao với giới hạn review công khai.
- Kiểm read-only tại D:/StartupOS: node docs/agents/validate.mjs và node --test docs/agents/validate.test.mjs. Validator không tự chạy queue/task commands; không thay domain review hay kiểm nội dung evidence.

