import { spawn } from "node:child_process";
import { retentionCases } from "./retention.ts";

async function runCommand(command: string, args: string[], env: NodeJS.ProcessEnv = process.env) {
    return new Promise<void>((resolve, reject) => {
        console.log(`> ${command} ${args.join(" ")}`);
        const executable = process.platform === "win32" && !command.endsWith(".cmd") && !command.endsWith(".exe")
            ? `${command}.cmd`
            : command;
        const child = spawn(executable, args, { stdio: "inherit", env });

        child.on("close", (code) => {
            if (code === 0) {
                resolve();
            } else {
                reject(new Error(`Command failed with exit code ${code}`));
            }
        });

        child.on("error", (err) => {
            reject(err);
        });
    });
}

async function main() {
    const args = process.argv.slice(2);
    const version = args[0]; // "next" or undefined (main)

    try {
        await runCommand("npm", ["run", "check"]);
        await runCommand("npm", ["run", "test:toolchain"]);

        // 1. Build
        console.log("\n--- Building ---");
        await runCommand("npm", ["run", "build"]);

        // 2. Test Source
        console.log("\n--- Testing Source ---");
        await runCommand("npx", ["tsx", "test/test.ts", ...args]);

        console.log("\n--- Testing Simulator Logging ---");
        await runCommand("npx", ["tsx", "test/test-simulator-logging.ts"]);

        // 2.3 Run an actual .noise simulation and validate header
        console.log("\n--- Running .noise simulation ---");
        await runCommand("npx", ["tsx", "test/test-noise-run.ts"]);
        // 2.4 Verify the FreePDK15 NMOS and PMOS card can be instantiated.
        console.log("\n--- Running FreePDK15 simulation ---");
        await runCommand("npx", ["tsx", "test/test-freepdk15.ts"]);
        // 2.5 Test WASM reuse
        console.log("\n--- Testing WASM reuse ---");
        await runCommand("npx", ["tsx", "test/test-wasm-reuse.ts"]);

        // 2.7 Test GF180
        console.log("\n--- Testing GF180 simulation ---");
        await runCommand("npx", ["tsx", "test/gf180/test.ts"]);

        // 3. Test Package
        console.log("\n--- Testing Package ---");
        await runCommand("npx", ["tsx", "test/test-package.ts", ...args]);

        await runCommand("npm", ["run", "test:consumer"]);

        // Exercise retention through both public entrypoints in fresh processes.
        for (const runtime of ["source", "package"]) {
            for (const fixture of [...retentionCases, "lifecycle"]) {
                await runCommand(process.execPath,
                    ["--import", "tsx", "test/test-heap-retention.mts", runtime, fixture]);
            }
        }

        // 4. Test Browser
        console.log("\n--- Testing Browser ---");
        const browserEnv = { ...process.env };
        if (version === "next") {
            browserEnv.REF_VERSION = "next";
        }
        await runCommand(
            "npx",
            ["playwright", "test", "test/test-browser-regression.spec.mts",
                "test/benchmark-opamp.spec.mts", "test/heap-retention.spec.mts"],
            browserEnv
        );

        console.log("\nAll tests passed successfully!");
    } catch (error) {
        console.error("\nTest run failed:", error);
        process.exit(1);
    }
}

main();
